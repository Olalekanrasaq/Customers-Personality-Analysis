# Customers' Personality Analysis
## by Olalekan Rasaq

## Dataset

> Customer Personality Analysis is a detailed analysis of a company’s ideal customers. It helps a business to better understand its customers and makes it easier for them to modify products according to the specific needs, behaviors and concerns of different types of customers.The datset was downloaded from [kaggle](www.kaggle.com). Some preliminary data wrangling were done on the dataset, these include;

- Drop extraneous columns. These are columns that are not useful for analysis.
- Convert customers' enrollment date to datetime and extract the year into a new column.
- Order the customers' educational level instead of a plain object type.
- Remove duplicated rows.
- Drop rows with missing values as well as outliers
- Reduce the marital status into just three groups; single, married and others.

## Summary of Findings

We explored our dataset by looking at univariate, bivariate and multivariate exploration. We discovered some interesting features from the dataset. Some of them are;

- Customers' income is positively related to their educational status'
- The income of a customer will determine how much he would spend on different products.
- Most customers receives income between 10,000 and 100,000.
- There is decrease in the amount spent by customers on products from 2012 to 2014.

We will explored these insights further in explanatory analysis

## Key Insights for Presentation

> Customers' income is a strong determining factor for customers' spending habit. 
